<?php
header("location: /");